# Simba — Gabungan Proyek

Empat paket asli digabung ke satu folder tanpa mengubah isinya (tidak ada file yang ditimpa).

| Folder | Asal zip | Isi |
|---|---|---|
| `frontend-react-lms-simba/` | lms-simba__1_.zip | React 19 + Vite + Tailwind 4 (modul Guru, ada tes vitest) |
| `frontend-react-rpl/` | Rekayasa-Perangkat-Lunak-main.zip | React 19 + Vite + Tailwind 4 (versi repo RPL, ada komponen student) |
| `frontend-ejs-prototype/` | simba-frontend.zip | Prototipe Node/EJS + CSS/JS statis |
| `backend-laravel-foundation/` | lms-simba-backend-1-sampai-10.zip | Overlay Laravel 12 (Backend 1–10), dipasang lewat `apply.sh` |

## Pembaruan (Prompt 8 — finalisasi)
`frontend-react-lms-simba/` adalah basis frontend yang difinalisasi (lihat README di dalamnya untuk status & verifikasi).
`frontend-react-rpl/` dan `frontend-ejs-prototype/` tidak diubah (referensi). `backend-laravel-foundation/` tidak diubah pada fase ini.
