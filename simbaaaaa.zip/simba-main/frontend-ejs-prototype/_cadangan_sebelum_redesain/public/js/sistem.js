const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

let timer;
function toast(t) {
  const el = $('#toast'); el.textContent = t; el.hidden = false;
  clearTimeout(timer); timer = setTimeout(() => (el.hidden = true), 3200);
}
$$('[data-toast]').forEach(b => b.addEventListener('click', () => toast(b.dataset.toast)));

// Tab: profil / tab belum didesain / backup (gulir ke modul backup)
$$('.sy-tab').forEach(b => b.addEventListener('click', () => {
  $$('.sy-tab').forEach(x => x.classList.toggle('is-active', x === b));
  const k = b.dataset.tab;
  if (k === 'backup') return $('#panel-backup').scrollIntoView({ behavior: 'smooth' });
  $$('.sy-panel').forEach(p => (p.hidden = p.id !== `panel-${k}`));
}));

// Favicon
$('#btnFavicon').addEventListener('click', () => $('#fileFavicon').click());
$('#fileFavicon').addEventListener('change', e => {
  const f = e.target.files[0];
  if (f) toast(`Favicon "${f.name}" dipilih. Sambungkan ke API backend untuk menyimpan.`);
});

// Cek NPSN (simulasi): validasi 8 digit
$('#btnCek').addEventListener('click', () => {
  const v = $('[name=npsn]').value.trim();
  toast(/^\d{8}$/.test(v) ? `NPSN ${v} terverifikasi (simulasi). Sambungkan ke API Kemendikbud.` : 'NPSN harus 8 digit angka.');
});

// Simpan konfigurasi: validasi form lalu kirim (TODO backend)
$('#btnSimpan').addEventListener('click', () => {
  const f = $('#formProfil');
  if (!f.reportValidity()) return toast('Periksa kembali isian yang ditandai.');
  const data = Object.fromEntries(new FormData(f));
  console.log('Konfigurasi siap dikirim:', data);
  toast('Konfigurasi disimpan (simulasi). Sambungkan ke API backend.');
  // TODO: fetch('/api/sistem/profil', { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) })
});

$('#btnUji').addEventListener('click', e => {
  const b = e.currentTarget; b.disabled = true; toast('Menguji koneksi server & SSO...');
  setTimeout(() => { b.disabled = false; toast('Koneksi server & SSO Kemendikbud OK (simulasi).'); }, 1200);
});
$('#btnDump').addEventListener('click', () => toast('Dump .SQL terenkripsi disiapkan (simulasi). Sambungkan ke backend.'));
