const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

let timer;
function toast(teks) {
  const t = $('#toast'); t.textContent = teks; t.hidden = false;
  clearTimeout(timer); timer = setTimeout(() => (t.hidden = true), 3200);
}
$$('[data-toast]').forEach(b => b.addEventListener('click', () => toast(b.dataset.toast)));

// Filter (tab fase + cari + status modul) lalu paginasi di sisi klien
const PER_HALAMAN = 5;
const total = Number($('#mpTabel').dataset.total);
const rows = $$('#mpBody tr[data-fase]');
let fase = 'semua', halaman = 1;

function terfilter() {
  const q = $('#mpCari').value.trim().toLowerCase(), st = $('#mpStatus').value;
  return rows.filter(r =>
    (fase === 'semua' || r.dataset.fase === fase) &&
    (!st || r.dataset.modul === st) &&
    (!q || r.textContent.toLowerCase().includes(q)));
}

function render() {
  const hasil = terfilter();
  const maks = Math.max(1, Math.ceil(hasil.length / PER_HALAMAN));
  halaman = Math.min(halaman, maks);
  const mulai = (halaman - 1) * PER_HALAMAN;
  rows.forEach(r => (r.hidden = true));
  hasil.slice(mulai, mulai + PER_HALAMAN).forEach(r => (r.hidden = false));
  $('#mpKosong').hidden = hasil.length > 0;

  const tampil = Math.min(PER_HALAMAN, Math.max(0, hasil.length - mulai));
  const dari = fase === 'semua' && !$('#mpCari').value && !$('#mpStatus').value ? total : hasil.length;
  $('#mpInfo').textContent = `Menampilkan ${tampil} dari ${dari} total mata pelajaran terdaftar`;

  const p = $('#mpPages');
  p.innerHTML = '';
  const buat = (teks, hal, opsi = {}) => {
    const b = document.createElement('button');
    b.textContent = teks;
    if (opsi.aktif) b.classList.add('is-active');
    if (opsi.mati) b.disabled = true;
    b.addEventListener('click', () => { halaman = hal; render(); });
    p.appendChild(b);
  };
  buat('Sebelumnya', halaman - 1, { mati: halaman === 1 });
  for (let i = 1; i <= maks; i++) buat(String(i), i, { aktif: i === halaman });
  buat('Selanjutnya', halaman + 1, { mati: halaman === maks });
}

$$('#mpTabs .pilltab').forEach(t => t.addEventListener('click', () => {
  $$('#mpTabs .pilltab').forEach(x => x.classList.remove('is-active'));
  t.classList.add('is-active'); fase = t.dataset.filter; halaman = 1; render();
}));
['#mpCari', '#mpStatus'].forEach(s => $(s).addEventListener('input', () => { halaman = 1; render(); }));
render();

// Sinkronisasi Dapodik (simulasi)
$('#btnSinkron').addEventListener('click', e => {
  const b = e.currentTarget;
  b.classList.add('syncing');
  setTimeout(() => {
    b.classList.remove('syncing');
    toast('Sinkronisasi Dapodik selesai (simulasi). Sambungkan ke API di backend.');
    // TODO: fetch('/api/dapodik/sinkron-mapel', { method: 'POST' })
  }, 1500);
});
