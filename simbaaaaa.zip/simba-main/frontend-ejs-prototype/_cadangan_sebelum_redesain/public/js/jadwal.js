const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

let timer;
function toast(teks) {
  const t = $('#toast'); t.textContent = teks; t.hidden = false;
  clearTimeout(timer); timer = setTimeout(() => (t.hidden = true), 3200);
}
$$('[data-toast]').forEach(b => b.addEventListener('click', () => toast(b.dataset.toast)));

// Tab hari
const NAMA_HARI = { senin: 'Senin', selasa: 'Selasa', rabu: 'Rabu', kamis: 'Kamis', jumat: 'Jumat' };
let hari = $('#dayTabs .is-active').dataset.hari;
function tampilHari() {
  $$('.jd-day').forEach(d => (d.hidden = d.dataset.hari !== hari));
  $('#jdHari').textContent = NAMA_HARI[hari];
}
$$('#dayTabs .daytab').forEach(t => t.addEventListener('click', () => {
  $$('#dayTabs .daytab').forEach(x => x.classList.remove('is-active'));
  t.classList.add('is-active'); hari = t.dataset.hari; tampilHari();
}));

// Pilih rombel (dummy: hanya mengganti judul; sambungkan ke API jadwal per rombel)
$('#jdRombel').addEventListener('change', e => {
  const nama = e.target.selectedOptions[0].dataset.nama;
  $$('.js-rombel').forEach(el => (el.textContent = nama));
  toast('Jadwal ' + nama + ' dimuat (simulasi).');
  // TODO: fetch(`/api/jadwal?rombel=${e.target.value}`)
});

// Cetak
$('#btnCetak').addEventListener('click', () => toast('Master jadwal PDF disiapkan (simulasi).'));
tampilHari();
