const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const rows = $$('#userBody tr[data-tipe]');
let tabAktif = 'semua';

// Filter tabel: tab peran + pencarian + status + jenjang
function terapkanFilter() {
  const q = $('#cari').value.trim().toLowerCase();
  const status = $('#fStatus').value;
  const jenjang = $('#fRombel').value;
  let tampil = 0;
  rows.forEach(tr => {
    const cocok =
      (tabAktif === 'semua' || tr.dataset.tipe === tabAktif) &&
      (!status || tr.dataset.status === status) &&
      (!jenjang || new RegExp('\\b' + jenjang + '\\b').test(tr.dataset.kelas)) &&
      (!q || tr.textContent.toLowerCase().includes(q));
    tr.hidden = !cocok;
    if (cocok) tampil++;
  });
  $('#kosong').hidden = tampil > 0;
}
$$('#roleTabs .tab').forEach(t => t.addEventListener('click', () => {
  $$('#roleTabs .tab').forEach(x => x.classList.remove('is-active'));
  t.classList.add('is-active');
  tabAktif = t.dataset.filter;
  terapkanFilter();
}));
['#cari', '#fStatus', '#fRombel'].forEach(s => $(s).addEventListener('input', terapkanFilter));

// Pilih semua baris yang terlihat
$('#cekSemua').addEventListener('change', e =>
  rows.filter(r => !r.hidden).forEach(r => ($('.cek', r).checked = e.target.checked)));

// Tombol "Tambah Pengguna Baru" -> scroll ke formulir
$('#btnTambah').addEventListener('click', () => {
  $('#formulir').scrollIntoView({ behavior: 'smooth' });
  $('#formAkun [name=nama]').focus({ preventScroll: true });
});

// Validasi formulir (tampilan). Pengiriman asli diurus backend.
$('#formAkun').addEventListener('submit', e => {
  e.preventDefault();
  const f = e.target, msg = $('#formMsg');
  const nomor = f.nomor.value.trim();
  const siswa = f.peran.value === 'Siswa';
  const errors = [];
  if (!f.nama.value.trim()) errors.push(['nama', 'Nama lengkap wajib diisi.']);
  if (!/^\d+$/.test(nomor) || nomor.length !== (siswa ? 10 : 18))
    errors.push(['nomor', siswa ? 'NISN harus 10 digit angka.' : 'NIP harus 18 digit angka.']);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.surel.value)) errors.push(['surel', 'Format surel belum benar.']);
  $$('input', f).forEach(i => i.classList.remove('invalid'));
  msg.hidden = false;
  if (errors.length) {
    errors.forEach(([n]) => f[n].classList.add('invalid'));
    msg.className = 'form-msg'; msg.textContent = errors[0][1];
    return;
  }
  msg.className = 'form-msg ok';
  msg.textContent = 'Data valid. Tinggal disambungkan ke API backend.';
  // TODO: fetch('/api/pengguna', { method: 'POST', body: new FormData(f) })
});

// Unggah CSV: klik atau drag & drop
const drop = $('#drop'), input = $('#csvFile');
function pilihFile(file) {
  if (!file) return;
  const salah = !file.name.toLowerCase().endsWith('.csv') ? 'Hanya file .csv yang diterima.'
    : file.size > 15 * 1024 * 1024 ? 'Ukuran file melebihi 15MB.' : '';
  $('#dropTitle').textContent = salah ? 'File ditolak' : file.name;
  $('#dropSub').textContent = salah || `${(file.size / 1024).toFixed(1)} KB siap diunggah`;
  // TODO: kirim file ke backend
}
input.addEventListener('change', () => pilihFile(input.files[0]));
['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => pilihFile(e.dataTransfer.files[0]));
