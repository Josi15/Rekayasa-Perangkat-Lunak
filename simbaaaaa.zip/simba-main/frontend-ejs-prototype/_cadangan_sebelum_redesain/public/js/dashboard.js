// Filter antrean pengguna berdasarkan tab (Semua / Guru / Siswa / Tendik)
document.querySelectorAll('#tabs .tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('#tabs .tab').forEach(t => t.classList.remove('is-active'));
    tab.classList.add('is-active');
    const f = tab.dataset.filter;
    document.querySelectorAll('.queue-item').forEach(li => {
      li.hidden = f !== 'semua' && li.dataset.tipe !== f;
    });
  });
});
