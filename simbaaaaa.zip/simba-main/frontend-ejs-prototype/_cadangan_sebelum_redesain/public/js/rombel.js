const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

// Daftar rombel: filter tab tingkat + pencarian
const cards = $$('#rbList .rb-card');
let tingkat = 'semua';
function filterRombel() {
  const q = $('#rbCari').value.trim().toLowerCase();
  let n = 0;
  cards.forEach(c => {
    const ok = (tingkat === 'semua' || c.dataset.tingkat === tingkat) && (!q || c.textContent.toLowerCase().includes(q));
    c.hidden = !ok; if (ok) n++;
  });
  $('#rbKosong').hidden = n > 0;
}
$$('#rbTabs .tab').forEach(t => t.addEventListener('click', () => {
  $$('#rbTabs .tab').forEach(x => x.classList.remove('is-active'));
  t.classList.add('is-active'); tingkat = t.dataset.filter; filterRombel();
}));
$('#rbCari').addEventListener('input', filterRombel);

// Daftar siswa: pencarian + gender + status
const rows = $$('#sBody tr[data-jk]');
function filterSiswa() {
  const q = $('#sCari').value.trim().toLowerCase(), g = $('#sGender').value, st = $('#sStatus').value;
  let n = 0;
  rows.forEach(r => {
    const ok = (!g || r.dataset.jk === g) && (!st || r.dataset.status === st) && (!q || r.textContent.toLowerCase().includes(q));
    r.hidden = !ok; if (ok) n++;
  });
  $('#sKosong').hidden = n > 0;
}
['#sCari', '#sGender', '#sStatus'].forEach(s => $(s).addEventListener('input', filterSiswa));

// Tombol kirim validasi (tampilan saja)
$('#btnKirim').addEventListener('click', () => {
  const t = $('#toast');
  t.textContent = 'Validasi rombel dikirim (simulasi). Sambungkan ke API Dapodik di backend.';
  t.hidden = false; setTimeout(() => (t.hidden = true), 3500);
  // TODO: fetch('/api/dapodik/kirim-rombel', { method: 'POST' })
});
