# LMS Simba — Frontend

Frontend **React 19 + Vite + Tailwind CSS 4** untuk LMS Simba (peran Siswa, Guru, Admin).
**Semua data adalah simulasi di memori, bukan database sungguhan.** Backend (Laravel 12 + PHP 8.4 + PostgreSQL)
belum terhubung; lapisan service sudah disiapkan agar bisa diganti ke API tanpa mengubah halaman.

## Tech stack
React 19 · React Router 7 · Tailwind CSS 4 (`@tailwindcss/vite`) · Lucide React · ExcelJS (ekspor leger) · Vite 8 ·
Vitest + Testing Library + jsdom · oxlint.

## Instalasi & perintah
Prasyarat: Node.js LTS.
```bash
npm install
cp .env.example .env        # opsional; atur VITE_API_BASE_URL untuk fase integrasi
npm run dev                 # http://localhost:5173
npm run build               # produksi → dist/
npm run preview
npm run lint                # oxlint
npm test                    # vitest run (tes UI + service + transport API)
npm run check:routes        # pemeriksa statis menu/rute/tautan (tanpa dependensi)
npm run verify              # lint + check:routes + test + build
```

## Akun demo
Data simulasi, **bukan akun sungguhan**; kata sandi sengaja publik dan hanya untuk demo. Halaman login punya tombol isi-otomatis.
Login menerima username, email, NISN, atau NIP.

| Peran | Username | Kata sandi |
|---|---|---|
| Siswa | `siswa` (juga `siti`) | `siswa123` |
| Guru | `guru` | `guru123` |
| Admin | `admin` | `admin123` |

Akun `budi` (guru, nonaktif) dan `dewi` (siswa, menunggu) ada untuk mendemonstrasikan penolakan login.
Akun yang dibuat admin lewat UI hanya bisa login bila admin mengisi "kata sandi sementara" (disimpan di memori saja).

## Rute aplikasi
| Area | Rute |
|---|---|
| Publik | `/login`, `/forgot-password`, `/403`, `*` → 404, `/` → `/login` |
| Siswa `/student` | `dashboard`, `subjects`, `materials`, `materials/:id`, `assignments`, `assignments/:id`, `grades`, `schedule`, `announcements` |
| Guru `/teacher` | `dashboard`, `schedule`, `materials`, `materials/new`, `materials/:id`, `materials/:id/edit`, `assignments`, `assignments/manage`, `assignments/new`, `assignments/:id`, `assignments/:id/edit`, `grading`, `grading/recap`, `attendance`, `quiz`, `profile`, `classes`, `classes/:id` |
| Admin `/admin` | `dashboard`, `users`, `classes`, `subjects`, `announcements`, `reports`, `settings` |

Catatan: `/teacher/classes` tidak punya item menu (desain guru hanya 8 menu); dicapai dari panel wali kelas di dashboard.
Menu sidebar bersumber dari `src/routes/navigation.js`; `npm run check:routes` memastikan tiap menu punya rute dan tiap tautan literal valid.

## Autentikasi simulasi & pembatasan peran
- Login memvalidasi ke `db` simulasi, lalu mengarahkan ke dashboard sesuai peran (`roleHome`). Logout menghapus sesi (dengan konfirmasi).
- Sesi di `localStorage` hanya menyimpan identitas; **peran dan status dibaca ulang dari `db` setiap sesi dipulihkan**, jadi mengubah `role` di localStorage tidak memberi akses. Menonaktifkan akun oleh admin mengakhiri sesinya.
- `ProtectedRoute` mengarahkan peran yang salah ke `/403` dan pengguna tanpa sesi ke `/login`.
- **Pembatasan ini hanya UX demo, bukan pengganti otorisasi backend.** Semua kode dan data klien dapat dilihat dan diubah pengguna. Otorisasi nyata (Sanctum + Policy, `role:` middleware) wajib di backend Laravel; banner "Mode demo" dan halaman 403 mengingatkan hal ini.

## Struktur folder
```
src/
  config/env.js          baca VITE_* (base URL API, jeda mock)
  components/{common,forms,layout,tables}   komponen reusable (FormModal, AsyncBoundary, DemoBanner, UserBadge, …)
  layouts/               DashboardLayout (+ per peran), AuthLayout
  pages/{auth,errors,student,teacher,admin}
  routes/                navigation.js (menu), *Routes.jsx, ProtectedRoute
  services/              http.js (mock + apiRequest), endpoints.js, db.js (data simulasi bersama), service per domain
  data/                  seed (users, demoAccounts, academic, teacher, quizzes, ledger, scheduleMatrix, teacherHome)
  contexts/ hooks/ utils/ styles/ test/
scripts/check-routes.mjs
```

## Konsistensi data & service layer
Semua data bersama hidup di **`src/services/db.js`** (users, classes, subjects, teachingClasses, materials, assignments, submissions,
schedules, announcements, settings). Halaman **hanya** mengimpor dari `src/services`, tidak dari `data/` atau `db.js`.

| Service | Peran |
|---|---|
| `authService` | login, sesi, logout, reset (simulasi) |
| `userService` | CRUD pengguna + aktif/nonaktif (admin) |
| `classService`, `subjectService` | CRUD kelas & mapel, arsip dengan pengecekan keterkaitan |
| `materialService`, `assignmentService`, `submissionService` | materi, tugas, pengumpulan & penilaian |
| `gradeService` | **nilai diturunkan** dari pengumpulan yang dinilai (bukan tabel terpisah) |
| `scheduleService` | jadwal per kelas / siswa / guru |
| `announcementService` | CRUD + penyaringan per peran & status |
| `reportService` | ringkasan & tabel CSV **dihitung dari `db`** |
| `settingService` | nama sekolah, tahun ajaran, semester |
| `teacherService`, `studentService`, `teacherAssignmentService`, `teacherHomeService`, … | fasad tampilan per peran di atas service domain |

Contoh yang tercakup tes: admin mengganti nama guru → tampil di kelas, mapel, jadwal, dan daftar peserta; guru menerbitkan tugas →
siswa melihat & mengumpulkan → guru menilai → nilai tampil di halaman Nilai siswa, Leger (Rata Tugas), dan Laporan; admin mengubah
tahun ajaran → tampil di halaman guru; pengumuman admin → tampil/tersaring di siswa.

## Status fitur
| Area | Status |
|---|---|
| Login, lupa kata sandi, logout, 403, 404 | ✅ simulasi |
| Guru: dashboard, jadwal, modul, tugas & penilaian, presensi, buku nilai/leger, kuis CBT, profil | ✅ UI + data simulasi |
| Siswa: dashboard, mapel, materi (+detail), tugas (+kumpul), nilai, jadwal, pengumuman | ✅ UI + data simulasi |
| Admin: dashboard, pengguna, kelas, mapel, pengumuman, laporan (CSV), pengaturan | ✅ UI + data simulasi |
| Integrasi backend Laravel | ⏳ belum (transport & peta endpoint disiapkan) |

## Yang masih simulasi / belum ada
- Seluruh data (bukan database; kembali ke seed saat reload). Tidak ada persistensi.
- Unggah/unduh berkas, foto profil, 2FA, Google Forms API, Dapodik, Buku Induk Rapor, pengiriman email reset: **tidak terhubung**.
- Ubah kata sandi hanya memvalidasi (aturan disamakan dengan backend: min 10 karakter, huruf besar+kecil+angka); tidak mengubah apa pun.
- Matriks jadwal mingguan guru, agenda dashboard, dan seed presensi/leger guru adalah fixture desain (`data/scheduleMatrix.js`, `teacherHome.js`, `attendanceStore.js`); **belum diturunkan dari `db.schedules`**, jadi ubahan jadwal tidak memengaruhinya.
- Keanggotaan kelas belum bisa diedit admin (diturunkan dari pengampuan guru); pengumuman bersasaran "Guru" belum punya halaman baca di sisi guru (hanya admin yang melihatnya).
- Halaman profil/pengaturan untuk Siswa dan Admin belum ada (menu desain hanya untuk guru).
- Predikat nilai < 75 belum didefinisikan di desain (ditampilkan "-").

## Persiapan integrasi backend (Laravel 12 + PostgreSQL)
1. **Env:** `VITE_API_BASE_URL=http://localhost:8000/api/v1` (lihat `.env.example`). Semua `VITE_*` publik.
2. **Autentikasi = Sanctum mode SPA (cookie + CSRF), bukan bearer token.** `apiRequest()` di `services/http.js` sudah memakai `credentials: 'include'`,
   mengambil `/sanctum/csrf-cookie` sebelum request tulis, mengirim `X-XSRF-TOKEN`, mengulang sekali pada 419, dan memetakan error
   `{message, code, errors, request_id}` ke `ApiError`. SPA dan API harus satu *site* (mis. `localhost:5173` + `localhost:8000`); atur
   `SANCTUM_STATEFUL_DOMAINS` dan `CORS_ALLOWED_ORIGINS` di backend. Login memakai `POST /auth/login {login, password}`.
3. **Peta endpoint:** `services/endpoints.js` (mis. `classes → /kelas`, `subjects → /mapel`, `users → /admin/pengguna`, `grades → /nilai`).
4. **Cara migrasi:** ganti isi `request(() => …)` tiap service dengan `apiRequest(...)`; kontrak method service (list/get/create/…) dan halaman tidak berubah.
   Bentuk respons sukses `{data, meta}` dan paginasi server perlu dipetakan (DataTable saat ini memaginasi di klien).
5. **Perbedaan kontrak yang perlu diputuskan:** istilah/status (`active|archived` vs enum DB), tugas/materi bertaut ke *mapel* di backend (di frontend lewat kelas+mapel pengampuan),
   nilai di backend adalah entitas (`/nilai`) sedangkan di frontend diturunkan; kebijakan admin tidak mengubah materi/tugas/nilai (lihat `AUTH.md`).
6. **Otorisasi, validasi, dan konfirmasi akun** harus ditegakkan di backend; validasi klien hanya UX.
7. Hapus `data/demoAccounts.js`, `db.js`, dan banner demo saat data sungguhan dipakai.

## Konsistensi desain
Token di `src/styles/index.css`: palet `brand-*` (hijau), `--radius-card`, `--shadow-card`, kelas `.card`, `.panel`, `.input`, `.btn-primary|secondary|danger`.
Skala radius: `rounded-lg` (kontrol), `rounded-xl` (kartu), `rounded-2xl` (panel besar). Warna bahaya/terlambat = `red-*` (sebelumnya modul guru memakai `rose-*`, sudah disamakan).
Responsif: sidebar menjadi laci di bawah `lg`, header ringkas dengan menu; tabel lebar berada di wadah `overflow-x-auto`; grid memakai breakpoint `sm/md/lg/xl`.
Modul siswa RPL (`frontend-react-rpl`) tidak dipindahkan mentah karena memakai dataset & palet sendiri; hanya tata letaknya (jadwal mingguan, daftar pengumuman, materi) dijadikan acuan.

## Status verifikasi (apa yang benar-benar dijalankan)
Lingkungan pengerjaan tidak punya akses registry npm, sehingga `npm install` **tidak bisa dijalankan** (`vite`, `vitest`, `oxlint`, `react-router-dom`, `lucide-react` tidak tersedia).
| Pemeriksaan | Hasil |
|---|---|
| Bundling seluruh aplikasi dengan esbuild (sintaks JSX + resolusi semua impor relatif, paket eksternal) | ✅ lolos |
| Parse seluruh berkas tes (`*.test.jsx`) | ✅ lolos |
| `tsc --checkJs`: identifier tak terdefinisi / ekspor-impor lokal salah | ✅ tidak ada temuan (hanya noise inferensi tipe JS) |
| `scripts/check-routes.mjs` (menu↔rute, 103 tautan literal) + uji negatif | ✅ lolos |
| `services.test.js` (12 tes) dan `http.test.js` (4 tes), dijalankan dengan runner Node minimal bergaya vitest (bukan vitest asli), + uji negatif runner | ✅ 16/16 lulus |
| `npm run build` (Vite), `npm run lint` (oxlint), `npm test` (vitest + jsdom) | ❌ **belum dijalankan** |
| 19 tes UI lama + `roles.test.jsx` (6 tes baru) | ❌ **belum dijalankan** |
| Pengecekan visual/responsif di browser, formulir secara interaktif | ❌ **belum dilakukan** (hanya audit statis kelas Tailwind) |

Perubahan yang dapat memengaruhi tes UI lama (perlu dijalankan di mesin Anda): kata sandi baru kini min 10 karakter + huruf besar/kecil/angka (tes profil disesuaikan),
`DemoBanner` dan header layout baru, `rose-*` → `red-*`, serta service yang dialihkan ke `db`. Jalankan `npm run verify` dan laporkan kegagalan bila ada.
